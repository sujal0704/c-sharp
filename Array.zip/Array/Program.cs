﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[3];
            a[0] = 25;
            a[1] = 50;
            a[2] = 75;

            foreach (int i in a)
            {
                Console.WriteLine(i);
            }
            Console.Read();
        }
    }
}
