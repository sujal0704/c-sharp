﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jagged_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] c = new int[3][];
            c[0] = new int[4] { 1, 2, 3, 4 };
            c[1] = new int[] { 5, 6, 7 };
            c[2] = new int[] { 8, 9 };

            for (int i = 0; i < c.Length; i++)
            {
                for (int j = 0; j < c[i].Length; j++)
                {
                    Console.Write(c[i][j] + " ");
                }
                Console.WriteLine();
            } Console.Read();
        }
    }
}
