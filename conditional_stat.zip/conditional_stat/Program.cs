﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace conditional_stat
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;
            Console.Write("Enter Your Age:");
            age = Convert.ToInt32(Console.ReadLine());
            if (age > 0)
            {
                if (age < 18)
                {
                    Console.WriteLine("Teenage");
                }
                else if (age >= 18 && age < 60)
                {
                    Console.WriteLine("Young");
                }
                else
                {
                    Console.WriteLine("Senior Citizen");
                }
            }
            else
            {
                Console.WriteLine("Birth Pending");
            }
            Console.Read();
        }
    }
}
